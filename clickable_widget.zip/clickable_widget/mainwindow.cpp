#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"clickable_widget_class.h"
#include<QDebug>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->widget_clcikable,SIGNAL(mousepressed()),this,SLOT(mousepressed()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousepressed()
{
    qDebug()<<"i am clicked";
}

