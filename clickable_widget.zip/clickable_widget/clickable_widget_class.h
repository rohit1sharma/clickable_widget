#ifndef CLICKABLE_WIDGET_CLASS_H
#define CLICKABLE_WIDGET_CLASS_H

#include <QObject>
#include <QWidget>
#include<QMouseEvent>
#include<QEvent>
#include<QDebug>

class clickable_widget_class : public QWidget
{
    Q_OBJECT
public:
    explicit clickable_widget_class(QWidget *parent = nullptr);

    void mousePressEvent(QMouseEvent *ev);

signals:
    void mousepressed();

public slots :

};

#endif // CLICKABLE_WIDGET_CLASS_H
