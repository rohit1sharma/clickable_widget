#include "clickable_widget_class.h"

clickable_widget_class::clickable_widget_class(QWidget *parent)
    : QWidget{parent}
{

}

void clickable_widget_class::mousePressEvent(QMouseEvent *ev)
{
    emit mousepressed();
}
